package com.aowlad.aowlad

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
