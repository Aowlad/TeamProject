import 'package:flutter/material.dart';
class FeedTabScreen extends StatefulWidget {
  const FeedTabScreen({Key? key}) : super(key: key);

  @override
  _FeedTabScreenState createState() => _FeedTabScreenState();
}

class _FeedTabScreenState extends State<FeedTabScreen> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
