import 'package:flutter/material.dart';
class HomeTabScreen extends StatefulWidget {
  const HomeTabScreen({Key? key}) : super(key: key);

  @override
  _HomeTabScreenState createState() => _HomeTabScreenState();
}

class _HomeTabScreenState extends State<HomeTabScreen> with SingleTickerProviderStateMixin{
  late TableBorder _tabController;
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
