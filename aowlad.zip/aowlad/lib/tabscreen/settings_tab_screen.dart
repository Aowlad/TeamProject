import 'package:flutter/material.dart';

class SettingsTabScreen extends StatefulWidget {
  const SettingsTabScreen({Key? key}) : super(key: key);

  @override
  _SettingsTabScreenState createState() => _SettingsTabScreenState();
}

class _SettingsTabScreenState extends State<SettingsTabScreen> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
